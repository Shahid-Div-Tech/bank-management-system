package application;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.*;
import java.util.*;

public class Main extends Application {

    /* ================= DATA STRUCTURES ================= */

    // Queue – Loan
    private Queue<Loan> loanQueue = new LinkedList<>();

    // HashTable – Accounts
    private HashTable accounts = new HashTable(20);

    // BST – Sorted Accounts
    private AccountBST bst = new AccountBST();

    // Graph – Branch Network
    private BankGraph graph = new BankGraph(5);

    // Stack – Navigation
    private Stack<Pane> navStack = new Stack<>();
    private StackPane root = new StackPane();

    /* ================= START ================= */

    @Override
    public void start(Stage stage) {

        // default graph
        graph.addEdge(0, 1);
        graph.addEdge(1, 2);
        graph.addEdge(2, 3);
        graph.addEdge(3, 4);

        showHome();

        Scene scene = new Scene(root, 900, 550);
        try {
            scene.getStylesheets().add(
                    Objects.requireNonNull(
                            getClass().getResource("application.css")
                    ).toExternalForm()
            );
        } catch (Exception ignored) {}

        stage.setTitle("🏦 Bank DSA Project - Improved");
        stage.setScene(scene);
        stage.show();
    }

    /* ================= HOME ================= */

    private void showHome() {
        VBox box = new VBox(20);
        box.setPadding(new Insets(30));
        box.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("🏦 Bank DSA Project");
        title.getStyleClass().add("title");

        HBox btns = new HBox(12);
        btns.setAlignment(Pos.CENTER);

        Button b1 = mainBtn("Loan Calculator (Queue)");
        Button b2 = mainBtn("Fixed Deposit Rates (Binary Search)");
        Button b3 = mainBtn("Account Directory (HashTable)");
        Button b4 = mainBtn("Sorted Accounts (BST)");
        Button b5 = mainBtn("Branch Network (Graph)");

        b1.setOnAction(e -> switchPage(loanPage()));
        b2.setOnAction(e -> switchPage(fdPage()));
        b3.setOnAction(e -> switchPage(accountPage()));
        b4.setOnAction(e -> switchPage(bstPage()));
        b5.setOnAction(e -> switchPage(graphPage()));

        btns.getChildren().addAll(b1, b2, b3, b4, b5);

        box.getChildren().addAll(title, btns);
        root.getChildren().setAll(box);
    }

    private Button mainBtn(String t) {
        Button b = new Button(t);
        b.getStyleClass().add("main-btn");
        return b;
    }

    private void switchPage(Pane p) {
        navStack.push((Pane) root.getChildren().get(0));
        root.getChildren().setAll(p);
    }

    private Button backBtn() {
        Button b = new Button("⬅ Back");
        b.getStyleClass().add("back-btn");
        b.setOnAction(e -> root.getChildren().setAll(navStack.pop()));
        return b;
    }

    /* ================= LOAN QUEUE ================= */

    private Pane loanPage() {
        VBox box = new VBox(10);
        box.setPadding(new Insets(25));

        Label title = new Label("Loan Queue");
        title.getStyleClass().add("section-title");

        TextField name = new TextField();
        name.setPromptText("Name");

        TextField amt = new TextField();
        amt.setPromptText("Loan Amount");

        Button add = mainBtn("Apply Loan");
        Button process = mainBtn("Process Next");

        Label out = new Label();
        ListView<String> list = new ListView<>();

        add.setOnAction(e -> {
            double a = Double.parseDouble(amt.getText());
            Loan l = new Loan(name.getText(), a, a * 0.10);
            loanQueue.add(l);
            out.setText("Added: " + l);
            refreshLoans(list);
        });

        process.setOnAction(e -> {
            Loan l = loanQueue.poll();
            out.setText(l == null ? "Queue Empty" : "Processed: " + l);
            refreshLoans(list);
        });

        HBox row = new HBox(10, name, amt, add);

        box.getChildren().addAll(title, row, process, out,
                new Label("Queue:"), list, backBtn());
        return box;
    }

    private void refreshLoans(ListView<String> list) {
        list.getItems().clear();
        for (Loan l : loanQueue) list.getItems().add(l.toString());
    }

    /* ================= FIXED DEPOSIT (BINARY SEARCH) ================= */

    private Pane fdPage() {
        VBox box = new VBox(12);
        box.setPadding(new Insets(25));

        Label title = new Label("Fixed Deposit Rate Lookup");
        title.getStyleClass().add("section-title");

        TextField amt = new TextField();
        amt.setPromptText("Deposit Amount");

        Button check = mainBtn("Check Rate");
        Label out = new Label();

        int[] thresholds = {0, 1000, 5000, 10000, 20000};
        double[] rates = {2, 3.5, 5, 6.5, 7.5};

        check.setOnAction(e -> {
            int val = Integer.parseInt(amt.getText());
            int idx = 0;
            for (int i = 0; i < thresholds.length; i++)
                if (val >= thresholds[i]) idx = i;
            out.setText("Rate: " + rates[idx] + "%");
        });

        box.getChildren().addAll(title, amt, check, out, backBtn());
        return box;
    }

    /* ================= ACCOUNT DIRECTORY (HASH TABLE) ================= */

    private Pane accountPage() {
        VBox box = new VBox(10);
        box.setPadding(new Insets(20));

        Label title = new Label("Account Directory (HashTable)");
        title.getStyleClass().add("section-title");

        TextArea area = new TextArea(accounts.toString());
        area.setEditable(false);

        TextField id = new TextField(); id.setPromptText("ID");
        TextField name = new TextField(); name.setPromptText("Name");
        TextField bal = new TextField(); bal.setPromptText("Balance");

        Button add = mainBtn("Add / Update Account");
        Button search = mainBtn("Search");
        Button del = mainBtn("Delete");
        Button save = mainBtn("Save to File");
        Button load = mainBtn("Reload from File");

        Label out = new Label();

        add.setOnAction(e -> {
            Account a = new Account(id.getText(), name.getText(),
                    Double.parseDouble(bal.getText()));
            accounts.put(a.id, a);
            bst.insert(a);
            area.setText(accounts.toString());
        });

        search.setOnAction(e -> {
            Account a = accounts.get(id.getText());
            out.setText(a == null ? "Not Found" : a.toString());
        });

        del.setOnAction(e -> {
            boolean r = accounts.remove(id.getText());
            area.setText(accounts.toString());
            out.setText(r ? "Deleted" : "Not Found");
        });

        save.setOnAction(e -> saveAccounts());
        load.setOnAction(e -> {
            loadAccounts();
            area.setText(accounts.toString());
        });

        box.getChildren().addAll(title, area,
                new HBox(8, id, name, bal),
                new HBox(8, add, search, del),
                new HBox(8, save, load),
                out, backBtn());

        return box;
    }

    /* ================= BST ================= */

    private Pane bstPage() {
        VBox box = new VBox(10);
        box.setPadding(new Insets(20));

        Label title = new Label("Accounts Sorted by Balance (BST)");
        title.getStyleClass().add("section-title");

        TextArea area = new TextArea();
        for (Account a : bst.sorted()) area.appendText(a + "\n");

        box.getChildren().addAll(title, area, backBtn());
        return box;
    }

    /* ================= GRAPH ================= */

    private Pane graphPage() {
        VBox box = new VBox(10);
        box.setPadding(new Insets(20));

        Label title = new Label("Bank Branch Network (Graph)");
        title.getStyleClass().add("section-title");

        TextArea area = new TextArea(graph.display());
        area.setEditable(false);

        box.getChildren().addAll(title, area, backBtn());
        return box;
    }

    /* ================= FILE HANDLING ================= */

    private void saveAccounts() {
        try (PrintWriter pw = new PrintWriter("accounts.txt")) {
            for (Account a : accounts.all())
                pw.println(a.id + "," + a.name + "," + a.bal);
        } catch (Exception ignored) {}
    }

    private void loadAccounts() {
        accounts = new HashTable(20);
        bst = new AccountBST();
        try (Scanner sc = new Scanner(new File("accounts.txt"))) {
            while (sc.hasNextLine()) {
                String[] p = sc.nextLine().split(",");
                Account a = new Account(p[0], p[1], Double.parseDouble(p[2]));
                accounts.put(a.id, a);
                bst.insert(a);
            }
        } catch (Exception ignored) {}
    }

    /* ================= MODELS & DSAs ================= */

    static class Loan {
        String n; double a, i;
        Loan(String n,double a,double i){this.n=n;this.a=a;this.i=i;}
        public String toString(){return n+" Loan="+a+" Int="+i;}
    }

    static class Account {
        String id,name; double bal;
        Account(String i,String n,double b){id=i;name=n;bal=b;}
        public String toString(){return id+" | "+name+" | "+bal;}
    }

    static class HashTable {
        LinkedList<Account>[] tab;
        HashTable(int s){tab=new LinkedList[s];
            for(int i=0;i<s;i++) tab[i]=new LinkedList<>();}
        int h(String k){return Math.abs(k.hashCode())%tab.length;}
        void put(String k,Account v){
            tab[h(k)].removeIf(a->a.id.equals(k));
            tab[h(k)].add(v);}
        Account get(String k){
            for(Account a:tab[h(k)]) if(a.id.equals(k)) return a;
            return null;}
        boolean remove(String k){return tab[h(k)].removeIf(a->a.id.equals(k));}
        List<Account> all(){
            List<Account> l=new ArrayList<>();
            for(var b:tab) l.addAll(b); return l;}
        public String toString(){
            StringBuilder sb=new StringBuilder();
            for(int i=0;i<tab.length;i++)
                for(Account a:tab[i]) sb.append("Bucket ").append(i)
                        .append(": ").append(a).append("\n");
            return sb.toString();}
    }

    static class AccountBST {
        static class N{Account a;N l,r;N(Account a){this.a=a;}}
        N root;
        void insert(Account a){root=ins(root,a);}
        N ins(N r,Account a){
            if(r==null) return new N(a);
            if(a.bal<r.a.bal) r.l=ins(r.l,a);
            else r.r=ins(r.r,a);
            return r;}
        List<Account> sorted(){
            List<Account> l=new ArrayList<>();
            in(root,l); return l;}
        void in(N r,List<Account>l){
            if(r!=null){in(r.l,l);l.add(r.a);in(r.r,l);}}
    }

    static class BankGraph {
        static class E{int d;E n;E(int d){this.d=d;}}
        E[] adj;
        BankGraph(int n){adj=new E[n];}
        void addEdge(int s,int d){E e=new E(d);e.n=adj[s];adj[s]=e;}
        String display(){
            StringBuilder sb=new StringBuilder();
            for(int i=0;i<adj.length;i++){
                sb.append("Branch ").append(i).append(" -> ");
                for(E e=adj[i];e!=null;e=e.n) sb.append(e.d).append(" ");
                sb.append("\n");
            }
            return sb.toString();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
